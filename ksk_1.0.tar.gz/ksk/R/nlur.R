nlur <-
function (y, k, type1=c('NN', 'DM', 'DT'),
                   model = c('KSS', 'Kruse'), title=title) {
  type1 <- match.arg(type1)
  model <- match.arg(model)
  warning("These functions consistency checks have not been \n made on data adopted in the KSS(2003) & Kruse(2008)")
  if (ncol(as.matrix(y)) > 1)
    if (ncol(as.matrix(y)) > 1)
      stop("y is not a vector or univariate time series")
  if (any(is.na(y)))
    stop("NAs in y")
  if (k < 0)
    stop("k negative")
  CALL <- match.call()
  DNAME <- deparse(substitute(y))
  x.name <- deparse(substitute(y))

  my <- mean(y)
  tr <- 1:length(y)
  lty <- summary(lm(y ~ + 1 + tr))
  ct <- lty$coefficients[2,1]

  if (type1 == 'DM'){
    y1=y-my   ## Demeaned
    if (model=='KSS')
      mod='KSS test on Demeaned data'
    if(model=='Kruse')
      mod = "Kruse test on Demeaned data"
  }
  if (type1 == 'DT'){
    y1 <- y-my-(ct*tr)  ## Demeaned and Detrended data'
    if (model=='KSS')
      mod='KSS test on Demeaned and Dtrended data'
    if (model=='Kruse')
      mod='Kruse test on Demeaned and Dtrended data'
  }
  if (type1 == 'NN'){
    y1 <- y  ## raw data'
    if  (model=='KSS')
      mod='KSS test on Raw data'
    if (model=='Kruse')
      mod='Kruse test on Raw data'
  }
  ### KSS & Kruse AUXILIARY REGRESSION CODES
  z3 <- embed(y1^3, k+1)
  z2 <- embed(y1^2, k+1)
  dt <- diff(y1)
  dyt <- embed(dt,k+1)
  xt1 <- z3[2:(length(y1)-k), 2]
  xt2 <- z2[2:(length(y1)-k), 2]
  yt <- dyt[,1]
  yt1 <- dyt[,2:(k+1)]
  N <- length(y1)
  n <- length(dt)

  if (k >= 1) {
    if (model=='KSS'){
      result <- lm(yt ~ xt1 + yt1 - 1)
    }
    if (model=='Kruse'){
      result <- lm(yt ~ xt1 +  xt2 + yt1 - 1)
    }
  }
  testreg <- summary(result)

  t_val_3 <- coef(summary(result))[1, 3]
  t_val_2 <- coef(summary(result))[2, 3]
  est_3 <- coef(summary(result))[1, 1]
  if (model=="KSS"){
    tau_val <- coef(summary(result))[1, 3]
  }
  if (model=="Kruse"){
    tau_val <- (t_val_3)^2 + (1*est_3)*(t_val_2)^2
  }
  teststat2 <- round(tau_val,4)
  list(title=title, mean=my, model=mod,
       auxiliary.Reg=testreg,
       cal.t_value=round(teststat2, 4))
}
