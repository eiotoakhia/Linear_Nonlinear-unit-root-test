ur <-
function(y, test = c("adf", "pp")){
  nlag1 = NULL
  nlag2 = NULL
  testvalue1 = NULL
  testvalue2 = NULL
  dec1 = NULL
  dec2 = NULL
  for (i in 1:dim(y)[2]){
    if (test == "pp"){
      x1 <- urca::ur.pp(y[, i], type="Z-tau", model="constant", lags="short")  ## PP TEST
      x2 <- urca::ur.pp(y[, i], type="Z-tau", model="trend", lags="short")  ## PP TEST
      a1=x1@lag
      a2=x2@lag
    }
    if (test == "adf"){
      x1=urca::ur.df(y[, i], type="drift", selectlags="AIC")
      x2=urca::ur.df(y[, i], type="trend", selectlags="AIC")
      a1=x1@lags
      a2=x2@lags
    }
    
    nlag1=rbind(nlag1, a1)
    nlag2=rbind(nlag2, a2)
    b1=x1@teststat[1]
    b2=x2@teststat[1]
    cv1=x1@cval[,2][1]
    cv2=x2@cval[,2][1]
    if (-(b1) >= -(cv1))
      decision1 = 'I(0)'
    else decision1 = 'I(1)'
    if (-(b2) >= -(cv2))
      decision2 = 'I(0)'
    else decision2 = 'I(1)'
    testvalue1=rbind(testvalue1,round(b1,2))
    testvalue2=rbind(testvalue2,round(b2,2))
    dec1 = rbind(dec1, decision1)
    dec2 = rbind(dec2, decision2)
  }
  const=cbind(colnames(y[]), testvalue1, dec1)
  trend=cbind(colnames(y[]), testvalue2, dec2)
  res=cbind(const,trend)[,c(-4)]
  colnames(res)=c('variables', 'const', 'decision', 'const & intercept', 'decision')
  return(res)
}
